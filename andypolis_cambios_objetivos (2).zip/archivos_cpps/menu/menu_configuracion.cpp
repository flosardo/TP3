#include "../../archivos_h/menu/menu_configuracion.h"

using namespace std;

Menu_configuracion::Menu_configuracion() {}

void Menu_configuracion::mostrar_menu() {
    cout << endl;
    cout << "𝕄𝔼ℕ𝕌" << endl;
    cout << "╔═══════════════════════════════════════════╗" << endl;
    cout << "║ 1. Modificar edificio por nombre          ║" << endl;
    cout << "║                                           ║" << endl;
    cout << "║ 2. Listar los edificios                   ║" << endl;
    cout << "║                                           ║" << endl;
    cout << "║ 3. Mostrar mapa                           ║" << endl;
    cout << "║                                           ║" << endl;
    cout << "║ 4. Comenzar partida                       ║" << endl;
    cout << "║                                           ║" << endl;
    cout << "║ 5. Guardar y salir                        ║" << endl;
    cout << "╚═══════════════════════════════════════════╝" << endl;
} 