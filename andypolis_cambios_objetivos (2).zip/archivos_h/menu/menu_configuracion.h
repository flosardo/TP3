#ifndef _MENU_CONFIGURACION_H_
#define _MENU_CONFIGURACION_H_
#include "menu.h"

class Menu_configuracion: public Menu {

    public:

        /*
        FALTAN LAS CONDICIONES
        */
        Menu_configuracion();
        
        /*
        FALTAN LAS CONDICIONES
        */
        void mostrar_menu();
};

#endif //_MENU_CONFIGURACION_H_