#ifndef _MENU_PARTIDA_H_
#define _MENU_PARTIDA_H_
#include "menu.h"

class Menu_partida : public Menu {

    public:

        /*
        FALTAN LAS CONDICIONES
        */
        Menu_partida();
        
        /*
        FALTAN LAS CONDICIONES
        */
        void mostrar_menu();
};

#endif //_MENU_PARTIDA_H_