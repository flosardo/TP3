#include "../archivos_h/materiales/madera.h"

int main(){
    Madera mat(20);
    mat.mostrar_estado();
    return 0;
}