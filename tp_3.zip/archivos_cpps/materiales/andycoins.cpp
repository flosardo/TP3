#include "../../archivos_h/materiales/andycoins.h"

Andycoins::Andycoins(unsigned int cantidad_inventario){
    nombre = ANDYCOINS;
    cantidad = cantidad_inventario;
}