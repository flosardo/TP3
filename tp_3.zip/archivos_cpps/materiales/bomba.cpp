#include "../../archivos_h/materiales/bomba.h"

Bomba::Bomba(unsigned int cantidad_inventario){
    nombre = BOMBA;
    cantidad = cantidad_inventario;
}