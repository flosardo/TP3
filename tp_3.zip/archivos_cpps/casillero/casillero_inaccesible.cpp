#include "../../archivos_h/casilleros/casillero_inaccesible.h"


using namespace std;

const static string COLOR_POR_DEFECTO  = "\e[0m";
const static string COLOR_DORADO = "\x1b[33m";

const char LAGO = 'L';
const char VACIO = ' ';
const int MIN_CANTIDAD_MATERIAL = 0;

CasilleroInaccesible::CasilleroInaccesible(){
    tipo_terreno = LAGO;
}

void CasilleroInaccesible::CasilleroInaccesible::mostrar(){
    cout << COLOR_DORADO << "══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð\n" << COLOR_POR_DEFECTO;
    cout << "Soy un casillero inaccesible, y no me encuentro vacío. Soy un Lago" << endl;
    cout << COLOR_DORADO << "══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð══ð\n" << COLOR_POR_DEFECTO;
}